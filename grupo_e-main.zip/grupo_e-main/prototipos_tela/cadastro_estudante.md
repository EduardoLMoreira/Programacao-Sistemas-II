# Controle de Estudantes

Nessas telas, um estudante poderá criar uma conta para ele utilizar em nossa plataforma, consultar e alterar suas informações, e deletar sua conta da nossa plataforma.

## Cadastro do estudante
![](https://github.com/ppads-2025s1/grupo_e/blob/main/prototipos_tela/img/cadastro_estudante.png)

## Consulta, alteração e delete do estudante
![](https://github.com/ppads-2025s1/grupo_e/blob/main/prototipos_tela/img/visualiza%C3%A7%C3%A3o_estudante.png)
