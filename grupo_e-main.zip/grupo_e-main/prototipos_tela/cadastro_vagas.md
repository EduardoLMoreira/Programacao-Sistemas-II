Nesta tela o RH da empresa interessada em cadastrar vagas vai poder especificar todos os detalhes da vaga que está publicando

## Campos do Formulário

- **Título da Vaga** - Nome do cargo ofertado (exemplo: "Estagiário de Marketing").
- **Carga Horária** - Opção para selecionar a quantidade de horas do estágio.
- **Área de Atuação** - Campo de seleção para definir a área profissional (TI, Administração, Engenharia, etc.).
- **Horário do Estágio** - Período do dia em que o estagiário atuará (Manhã, Tarde, Flexível, etc.).
- **Requisitos** - Lista de conhecimentos, cursos ou habilidades necessárias para a vaga.
- **Diferenciais** - Habilidades ou experiências desejáveis, mas não obrigatórias.
- **Modalidade** - Define o tipo de atuação (Presencial, Híbrido ou Remoto).

## Botão de Ação

No canto inferior direito da tela, há um botão circular rosa com um ícone de seta ">". Esse botão é utilizado para avançar para enviar o cadastro da vaga.
