# Controle de Empresas

Nessas telas, um funcionário da empresa poderá criar uma conta para utilizar a nossa plataforma, consultar e alterar suas informações, e deletar sua conta.

## Cadastro da empresa
![](https://github.com/ppads-2025s1/grupo_e/blob/main/prototipos_tela/img/cadastro_empresa.png)

## Consulta, alteração e delete da empresa
![](https://github.com/ppads-2025s1/grupo_e/blob/main/prototipos_tela/img/visualiza%C3%A7%C3%A3o_empresa.png)
