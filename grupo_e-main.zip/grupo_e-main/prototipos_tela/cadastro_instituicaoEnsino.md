# Controle de Instituições

Nessas telas, alguém da instuição poderá cadastrar, alterar e excluir sua instituição na nossa plataforma.

## Cadastro da Instituição
![](https://github.com/ppads-2025s1/grupo_e/blob/main/prototipos_tela/img/cadastro_instituicaoEnsino.png)

# Consulta, alteração e delete da instituição
![](https://github.com/ppads-2025s1/grupo_e/blob/main/prototipos_tela/img/visualização_instituicaoEnsino.png)
