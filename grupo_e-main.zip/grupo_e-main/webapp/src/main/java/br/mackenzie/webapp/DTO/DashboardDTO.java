package br.mackenzie.webapp.DTO;

import java.util.List;

public class DashboardDTO {

    private long totalEstudantes; 
    private long totalEmpresas;
    private long totalPropostas;
    private long totalInscricoes;
    private List<CompanyOffersDTO> topCompanies;

    public DashboardDTO(long totalEstudantes, long totalEmpresas, long totalPropostas, long totalInscricoes) {
        this.totalEstudantes = totalEstudantes;
        this.totalEmpresas = totalEmpresas;
        this.totalPropostas = totalPropostas;
        this.totalInscricoes = totalInscricoes;
    }

    public DashboardDTO() {}

    public List<CompanyOffersDTO> getTopCompanies() {
        return topCompanies;
    }
    public void setTopCompanies(List<CompanyOffersDTO> topCompanies) {
        this.topCompanies = topCompanies;
    }
    public long getTotalEmpresas() {
        return totalEmpresas;
    }
    public void setTotalEmpresas(long totalEmpresas) {
        this.totalEmpresas = totalEmpresas;
    }
    public long getTotalEstudantes() {
        return totalEstudantes;
    }
    public void setTotalEstudantes(long totalEstudantes) {
        this.totalEstudantes = totalEstudantes;
    }
    public long getTotalInscricoes() {
        return totalInscricoes;
    }
    public void setTotalInscricoes(long totalInscricoes) {
        this.totalInscricoes = totalInscricoes;
    }
    public long getTotalPropostas() {
        return totalPropostas;
    }
    public void setTotalPropostas(long totalPropostas) {
        this.totalPropostas = totalPropostas;
    }
    
}
