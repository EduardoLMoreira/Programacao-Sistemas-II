package br.mackenzie.webapp.controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import br.mackenzie.webapp.entidades.Empresa;
import br.mackenzie.webapp.repos.EmpresaRepo;

@RestController
class EmpresaController {

	@Autowired
	private EmpresaRepo empresaRepo;

	public EmpresaController() {

	}

	@GetMapping("/api/empresa")
	Iterable<Empresa> getEmpresa(@RequestParam Optional<Long> empresaId) {
		return empresaRepo.findAll();

	}

	@GetMapping("/api/empresa/{id}")
	Optional<Empresa> getEmpresa(@PathVariable long id) {
		return empresaRepo.findById(id);
	}

	@GetMapping("/api/proc-empresas/{termo}")
    List<Empresa> getEmpresaByTermo(@PathVariable String termo) {
        return empresaRepo.searchByTerm(termo);
    }

    @PostMapping("/api/login-empresa")
    Optional<Empresa> getLoginEstudante(@RequestParam String username, @RequestParam String password) {
        return empresaRepo.login(username, password);
    }

	@PostMapping("/api/empresa")
	Empresa createEmpresa(@RequestBody Empresa e) {
		Empresa createdEmpr = empresaRepo.save(e);
		return createdEmpr;
	}

	@PutMapping("/api/empresa/{empresaId}")
	Optional<Empresa> updateEmpresa(@RequestBody Empresa empresaRequest, @PathVariable long empresaId) {
		Optional<Empresa> opt = empresaRepo.findById(empresaId);
		if (opt.isPresent()) {
			if (empresaRequest.getId() == empresaId) {
				empresaRepo.save(empresaRequest);
				return opt;
			}
		}
		throw new ResponseStatusException(HttpStatus.NOT_FOUND,
				"Erro ao alterar dados da empresa com id " + empresaId);
	}

	@DeleteMapping(value = "/api/empresa/{id}")
	void deleteEmpresa(@PathVariable long id) {
		empresaRepo.deleteById(id);
	}
}