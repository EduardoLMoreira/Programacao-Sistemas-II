package br.mackenzie.webapp.repos;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import br.mackenzie.webapp.entidades.InstituicaoEnsino;

public interface InstituicaoEnsinoRepo extends CrudRepository<InstituicaoEnsino, Long> {

    @Query("SELECT i FROM InstituicaoEnsino i WHERE " +
        "LOWER(i.nomeInstituicao) LIKE LOWER(CONCAT('%', :termo, '%')) OR " +
        "LOWER(i.qtdFuncionarios) LIKE LOWER(CONCAT('%', :termo, '%')) OR " +
        "LOWER(i.CNPJ) LIKE LOWER(CONCAT('%', :termo, '%')) OR " +
        "LOWER(i.emailCorporativo) LIKE LOWER(CONCAT('%', :termo, '%')) OR " +
        "LOWER(i.CEP) LIKE LOWER(CONCAT('%', :termo, '%'))")
    List<InstituicaoEnsino> searchByTerm(@Param("termo") String termo);
}