package br.mackenzie.webapp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.core.env.Environment;

import jakarta.annotation.PostConstruct;

@SpringBootApplication
public class WebApp {

    @Autowired
    private Environment env;

    @PostConstruct
    public void debugDbUrl() {
        System.out.println(">>>> SPRING DB URL = " + env.getProperty("spring.datasource.url"));
    }

	public static void main(String[] args) {
		SpringApplication.run(WebApp.class, args);
	}
}