package br.mackenzie.webapp.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.mackenzie.webapp.DTO.CompanyOffersDTO;
import br.mackenzie.webapp.DTO.DashboardDTO;
import br.mackenzie.webapp.repos.DashboardRepo;

@RestController
@RequestMapping("/api")
public class DashboardController {
    
    @Autowired
    private DashboardRepo repo;

    @GetMapping("/dashboard")
    public DashboardDTO getDashboard() {

        DashboardDTO dashboard = repo.getDashboardStatistics();
        List<CompanyOffersDTO> topCompanies = repo.getTopCompanies();
        dashboard.setTopCompanies(topCompanies);
        return dashboard;
    }
    
}