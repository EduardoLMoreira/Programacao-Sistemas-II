package br.mackenzie.webapp.controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import org.springframework.web.server.ResponseStatusException;

import br.mackenzie.webapp.entidades.Proposta;
import br.mackenzie.webapp.repos.PropostaRepo;

@RestController
class PropostaController {

    @Autowired
    private PropostaRepo propostaRepo;

    @GetMapping("/api/propostas")
    List<Proposta> getPropostas(@RequestParam Optional<Long> propostaId) {
        return propostaRepo.procurarTodosAbertos();
    }

    @GetMapping("/api/propostas/{id}")
    Optional<Proposta> getProposta(@PathVariable long id) {
        return propostaRepo.findById(id);
    }

    @GetMapping("/api/proc-proposta/{termo}")
    List<Proposta> getPropostaByTermo(@PathVariable String termo) {
        return propostaRepo.searchByTerm(termo);
    }

    @PostMapping("/api/propostas-estudante")
    List<Proposta> getPropostaById(@RequestParam long estudante_id) {
        return propostaRepo.propostasPorId(estudante_id);
    }

    @PostMapping("/api/propostas-empresa")
    List<Proposta> getPropostaByEmpresaId(@RequestParam long empresa_id) {
        return propostaRepo.procurarPropostasEmpresa(empresa_id);
    }

    @PostMapping("/api/propostas")
    Proposta createProposta(@RequestBody Proposta p) {
        return propostaRepo.save(p);
    }

    @PutMapping("/api/update-propostas/{propostaId}")
    Optional<Proposta> updateProposta(@RequestBody Proposta propostaRequest, @PathVariable long propostaId) {
        Optional<Proposta> opt = propostaRepo.findById(propostaId);
        if (opt.isPresent()) {
            if (propostaRequest.getId() == propostaId) {
                propostaRepo.save(propostaRequest);
                return opt;
            }
        }
        throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Erro ao alterar proposta com id " + propostaId);
    }

    @DeleteMapping("/api/propostas/{id}")
    void deleteProposta(@PathVariable long id) {
        propostaRepo.deleteById(id);
    }
}
