package br.mackenzie.webapp.controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import br.mackenzie.webapp.entidades.Estudante;
import br.mackenzie.webapp.repos.EstudanteRepo;

@RestController
class EstudanteController {

	@Autowired
	private EstudanteRepo estudanteRepo;

	public EstudanteController() {

	}

	@GetMapping("/api/estudantes")
	Iterable<Estudante> getEstudantes(@RequestParam Optional<Long> estudanteId) {

		return estudanteRepo.findAll();

	}

	@GetMapping("/api/estudante/{id}")
	Optional<Estudante> getEstudante(@PathVariable long id) {
		return estudanteRepo.findById(id);
	}

    @GetMapping("/api/proc-estudantes/{termo}")
    List<Estudante> getEstudanteByTermo(@PathVariable String termo) {
        return estudanteRepo.searchByTerm(termo);
    }

    @PostMapping("/api/login-estudante")
    Optional<Estudante> getLoginEstudante(@RequestParam String username, @RequestParam String password) {
        return estudanteRepo.login(username, password);
    }

	@PostMapping("/api/estudantes")
	Estudante createProfessor(@RequestBody Estudante e) {
		Estudante createdEstud = estudanteRepo.save(e);
		return createdEstud;
	}

	@PutMapping("/api/estudantes/{estudanteId}")
	Optional<Estudante> updateEstudante(@RequestBody Estudante estudanteRequest, @PathVariable long estudanteId) {
		Optional<Estudante> opt = estudanteRepo.findById(estudanteId);
		if (opt.isPresent()) {
			if (estudanteRequest.getId() == estudanteId) {
				estudanteRepo.save(estudanteRequest);
				return opt;
			}
		}
		throw new ResponseStatusException(HttpStatus.NOT_FOUND,
				"Erro ao alterar dados do estudante com id " + estudanteId);
	}

	@DeleteMapping(value = "/api/estudantes/{id}")
	void deleteEstudante(@PathVariable long id) {
		estudanteRepo.deleteById(id);
	}
}
