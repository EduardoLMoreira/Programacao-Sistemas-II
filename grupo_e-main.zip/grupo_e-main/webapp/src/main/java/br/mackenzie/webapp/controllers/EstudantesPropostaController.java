package br.mackenzie.webapp.controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import br.mackenzie.webapp.entidades.Estudante;
import br.mackenzie.webapp.entidades.EstudantesProposta;
import br.mackenzie.webapp.entidades.Proposta;
import br.mackenzie.webapp.repos.EstudantesPropostaRepo;
import br.mackenzie.webapp.repos.PropostaRepo;

@RestController
public class EstudantesPropostaController {

    @Autowired
    private PropostaRepo prop_repo;

    @Autowired
    private EstudantesPropostaRepo repo;

    @PostMapping("/api/inscrever-proposta")
    EstudantesProposta createEstudanteProposta(@RequestBody EstudantesProposta ep) {
        return repo.save(ep);
    }
    
    @PostMapping("/api/resgatar-propostas")
    public List<Proposta> getPropostasDisponiveis(@RequestParam(required = false) Long estudanteId) {
        if (estudanteId == null || estudanteId == 0) {
            return prop_repo.findAll();
        }
        return prop_repo.findPropostasNotSubscribedByEstudante(estudanteId);
    }
    
    @PostMapping("/api/resgatar-propostas-estudante")
    List<Proposta> resgatarPropostasEstudante(@RequestParam long estudanteId) {
        return repo.procurarPropostasEstudante(estudanteId);
    }
    
    @PostMapping("/api/resgatar-propostas-empresa")
    List<PropostaComEstudantesDTO> resgatarPropostasEmpresa(@RequestParam long empresaId) {

        List<Proposta> propostas = prop_repo.findPropostasByEmpresa(empresaId);
        List<PropostaComEstudantesDTO> resultado = new ArrayList<>();

        for (Proposta proposta : propostas) {
            List<Estudante> estudantes = repo.findEstudanteIdsByPropostaId(proposta.getId());
            resultado.add(new PropostaComEstudantesDTO(proposta, estudantes));
        }
        return resultado;
    }
    
}

class PropostaComEstudantesDTO {
    private Proposta proposta;
    private List<Estudante> estudantes;

    public PropostaComEstudantesDTO(Proposta proposta, List<Estudante> estudantes) {
        this.proposta = proposta;
        this.estudantes = estudantes;
    }

    public List<Estudante> getEstudantes() {
        return estudantes;
    }
    public Proposta getProposta() {
        return proposta;
    }

}