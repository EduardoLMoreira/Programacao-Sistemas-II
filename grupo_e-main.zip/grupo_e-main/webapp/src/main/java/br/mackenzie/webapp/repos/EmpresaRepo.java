package br.mackenzie.webapp.repos;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import br.mackenzie.webapp.entidades.Empresa;

public interface EmpresaRepo extends CrudRepository<Empresa, Long> {

    @Query("SELECT e FROM Empresa e WHERE " +
       "LOWER(e.nome) LIKE LOWER(CONCAT('%', :termo, '%')) OR " +
       "LOWER(e.CNPJ) LIKE LOWER(CONCAT('%', :termo, '%')) OR " +
       "LOWER(e.emailCorporativo) LIKE LOWER(CONCAT('%', :termo, '%')) OR " +
       "LOWER(e.qtdFuncionarios) LIKE LOWER(CONCAT('%', :termo, '%')) OR " +
       "LOWER(e.ramo) LIKE LOWER(CONCAT('%', :termo, '%')) OR " +
       "LOWER(e.CEP) LIKE LOWER(CONCAT('%', :termo, '%'))")
    List<Empresa> searchByTerm(@Param("termo") String termo);

    @Query("SELECT e FROM Empresa e WHERE " +
       "e.nome = :username AND " +
       "e.senha = :password")
    Optional<Empresa> login(@Param("username") String username, @Param("password") String password);
}