package br.mackenzie.webapp.entidades;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="estudantes")
public class Estudante {

	@Id @GeneratedValue
	private long id;

	private String nome;
    private String senha;
    private String faculdade;
    private String curso;
    private String dataFormacao;
		
	public Estudante() {
		super();
	}

    public long getId() {
        return this.id;
    }

    public String getNome() {
        return this.nome;
    }

    public String getSenha() {
        return this.senha;
    }

    public String getFaculdade() {
        return this.faculdade;
    }

    public String getCurso() {
        return this.curso;
    }

    public String getDataFormacao() {
        return this.dataFormacao;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    public void setSenha(String senha) {
        this.senha = senha;
    }
    public void setFaculdade(String faculdade) {
        this.faculdade = faculdade;
    }
    public void setCurso(String curso) {
        this.curso = curso;
    }
    public void setDataFormacao(String dataFormacao) {
        this.dataFormacao = dataFormacao;
    }

}
