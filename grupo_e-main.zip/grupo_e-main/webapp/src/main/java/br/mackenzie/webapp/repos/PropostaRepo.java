package br.mackenzie.webapp.repos;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;


import br.mackenzie.webapp.entidades.Proposta;

public interface PropostaRepo extends CrudRepository<Proposta, Long> {
    @Query("SELECT p FROM Proposta p WHERE " +
       "LOWER(p.descricao) LIKE LOWER(CONCAT('%', :termo, '%')) OR " +
       "LOWER(p.status) LIKE LOWER(CONCAT('%', :termo, '%')) OR " +
       "CAST(p.estudanteId AS string) LIKE LOWER(CONCAT('%', :termo, '%'))")
    List<Proposta> searchByTerm(@Param("termo") String termo);

    @Query("SELECT p FROM Proposta p WHERE " +
       "p.estudanteId = :id")
    List<Proposta> propostasPorId(@Param("id") Long estudante_id);

    @Query("SELECT p FROM Proposta p WHERE p.estudanteId = 0")
    List<Proposta> procurarTodosAbertos();

    @Query("SELECT p FROM Proposta p WHERE p.empresaId = :id")
    List<Proposta> procurarPropostasEmpresa(@Param("id") Long empresa_id);

    @Query("SELECT p FROM Proposta p WHERE p.empresa.id = :empresaId")
    List<Proposta> findPropostasByEmpresa(@Param("empresaId") Long empresaId);

    @SuppressWarnings("null")
    @Override
    List<Proposta> findAll();

    @Query("""
        SELECT p FROM Proposta p
        WHERE p.id NOT IN (
            SELECT ep.propostaId FROM EstudantesProposta ep
            WHERE ep.estudanteId = :estudanteId
        )
    """)
    List<Proposta> findPropostasNotSubscribedByEstudante(@Param("estudanteId") Long estudanteId);

}