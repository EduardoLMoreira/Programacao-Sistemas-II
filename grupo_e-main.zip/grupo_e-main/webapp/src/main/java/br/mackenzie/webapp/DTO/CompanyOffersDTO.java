package br.mackenzie.webapp.DTO;

public class CompanyOffersDTO {
    private String empresaNome;
    private long totalOfertas;

    public CompanyOffersDTO(String empresa, long totalOfertas) {
        this.empresaNome = empresa;
        this.totalOfertas = totalOfertas;
    }

    public String getEmpresaNome() {
        return empresaNome;
    }
    public void setEmpresaNome(String empresaNome) {
        this.empresaNome = empresaNome;
    }
    public long getTotalOfertas() {
        return totalOfertas;
    }
    public void setTotalOfertas(long totalOfertas) {
        this.totalOfertas = totalOfertas;
    }

}
