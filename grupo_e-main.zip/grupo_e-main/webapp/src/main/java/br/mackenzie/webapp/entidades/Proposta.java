package br.mackenzie.webapp.entidades;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="propostas")
public class Proposta {

    @Id @GeneratedValue
    private long id;
    
    private String descricao;
    private String status; // Exemplo: "Pendente", "Aprovada", "Rejeitada"
    private long estudanteId; // Armazena o ID do aluno, sem precisar da classe Estudante.java
    private long empresaId; // Armazena o ID do aluno, sem precisar da classe Estudante.java

    @ManyToOne
    @JoinColumn(name = "empresaId", insertable = false, updatable = false)
    private Empresa empresa;

    public Proposta() { super(); }

    public long getId() { return id; }
    public String getDescricao() { return descricao; }
    public String getStatus() { return status; }
    public long getEstudanteId() { return estudanteId; } // Retorna apenas o ID do estudante
    public long getEmpresaId() { return empresaId; }

    public void setDescricao(String descricao) { this.descricao = descricao; }
    public void setStatus(String status) { this.status = status; }
    public void setEstudanteId(long estudanteId) { this.estudanteId = estudanteId; } // Define o ID do estudante
    public void setEmpresaId(long empresaId) { this.empresaId = empresaId; } // Define o ID do estudante
}