package br.mackenzie.webapp.repos;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import br.mackenzie.webapp.DTO.CompanyOffersDTO;
import br.mackenzie.webapp.DTO.DashboardDTO;
import br.mackenzie.webapp.entidades.Proposta;

@Repository
public interface DashboardRepo extends JpaRepository<Proposta, Long> {

    @Query("""
    SELECT new br.mackenzie.webapp.DTO.DashboardDTO(
        (SELECT COUNT(*) FROM Estudante),
        (SELECT COUNT(*) FROM Empresa),
        (SELECT COUNT(*) FROM Proposta),
        (SELECT COUNT(*) FROM EstudantesProposta)
    )
    """)
    DashboardDTO getDashboardStatistics();

    @Query("""
        SELECT new br.mackenzie.webapp.DTO.CompanyOffersDTO(e.nome, COUNT(p)) 
        FROM Empresa e 
        JOIN Proposta p ON p.empresaId = e.id 
        GROUP BY e.nome 
        ORDER BY COUNT(p) DESC 
        LIMIT 10
    """)
    List<CompanyOffersDTO> getTopCompanies();
}