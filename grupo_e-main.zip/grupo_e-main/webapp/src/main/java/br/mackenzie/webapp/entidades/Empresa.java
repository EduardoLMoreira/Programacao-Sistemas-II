package br.mackenzie.webapp.entidades;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="empresas")
public class Empresa {

	@Id @GeneratedValue
	private long id;

	private String nome;
	private String senha;
	private String CNPJ;
	private String emailCorporativo;
	private String qtdFuncionarios;
	private String ramo;
	private String CEP;
		
	public Empresa() {
		super();
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}
	
	public String getNome() {
		return this.nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getSenha() {
		return this.senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}
	
	public String getCNPJ() {
		return this.CNPJ;
	}

	public void setCNPJ(String CNPJ) {
		this.CNPJ = CNPJ;
	}
	
	public String getEmailCorporativo() {
		return this.emailCorporativo;
	}

	public void setEmailCorporativo(String emailCorporativo) {
		this.emailCorporativo = emailCorporativo;
	}

	public String getQtdFuncionarios() {
		return this.qtdFuncionarios;
	}

	public void setQtdFuncionarios(String qntFuncionarios) {
		this.qtdFuncionarios = qntFuncionarios;
	}
	
	public String getRamo() {
		return this.ramo;
	}

	public void setRamo(String ramo) {
		this.ramo = ramo;
	}

	public String getCEP() {
		return this.CEP;	
	}

	public void setCEP(String CEP) {
		this.CEP = CEP;
	}

}