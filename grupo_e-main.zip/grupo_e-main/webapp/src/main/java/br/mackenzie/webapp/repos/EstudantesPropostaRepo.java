package br.mackenzie.webapp.repos;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import br.mackenzie.webapp.entidades.Estudante;
import br.mackenzie.webapp.entidades.EstudantesProposta;
import br.mackenzie.webapp.entidades.Proposta;

public interface EstudantesPropostaRepo extends CrudRepository<EstudantesProposta, Long>{
    
    @Query("SELECT ep.proposta FROM EstudantesProposta ep WHERE ep.estudanteId = :estu_id")
    List<Proposta> procurarPropostasEstudante(@Param("estu_id") Long id);

    @Query("SELECT ep.estudante FROM EstudantesProposta ep WHERE ep.propostaId = :propostaId")
    List<Estudante> findEstudanteIdsByPropostaId(@Param("propostaId") Long propostaId);

}
