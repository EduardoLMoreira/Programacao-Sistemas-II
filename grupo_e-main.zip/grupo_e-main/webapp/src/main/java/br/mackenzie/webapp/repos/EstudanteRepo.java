package br.mackenzie.webapp.repos;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import br.mackenzie.webapp.entidades.Estudante;

public interface EstudanteRepo extends CrudRepository<Estudante, Long> {

    @Query("SELECT e FROM Estudante e WHERE " +
       "LOWER(e.nome) LIKE LOWER(CONCAT('%', :termo, '%')) OR " +
       "LOWER(e.faculdade) LIKE LOWER(CONCAT('%', :termo, '%')) OR " +
       "LOWER(e.curso) LIKE LOWER(CONCAT('%', :termo, '%')) OR " +
       "LOWER(e.dataFormacao) LIKE LOWER(CONCAT('%', :termo, '%'))")
    List<Estudante> searchByTerm(@Param("termo") String termo);

    @Query("SELECT e FROM Estudante e WHERE " +
       "e.nome = :username AND " +
       "e.senha = :password")
    Optional<Estudante> login(@Param("username") String username, @Param("password") String password);
}