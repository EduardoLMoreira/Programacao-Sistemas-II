 package br.mackenzie.webapp.controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import br.mackenzie.webapp.entidades.InstituicaoEnsino;
import br.mackenzie.webapp.repos.InstituicaoEnsinoRepo;

@RestController
class InstituicaoEnsinoController {

	@Autowired
	private InstituicaoEnsinoRepo InstituicaoEnsinoRepo;

	public InstituicaoEnsinoController() {

	}

	@GetMapping("/api/instituicaoEnsino")
	Iterable<InstituicaoEnsino> getInstituicoesEnsino(@RequestParam Optional<Long> instituicaoEnsinoId) {

		return InstituicaoEnsinoRepo.findAll();

	}

	@GetMapping("/api/proc-instituicaoEnsino/{termo}")
    List<InstituicaoEnsino> getInstituicaoEnsinoByTermo(@PathVariable String termo) {
        return InstituicaoEnsinoRepo.searchByTerm(termo);
    }

	@GetMapping("/api/instituicaoEnsino/{id}")
	Optional<InstituicaoEnsino> getInstituicoesEnsino(@PathVariable long id) {
		return InstituicaoEnsinoRepo.findById(id);
	}

	@PostMapping("/api/instituicaoEnsino")
	InstituicaoEnsino createInstituicoesEnsino(@RequestBody InstituicaoEnsino p) {
		InstituicaoEnsino createdInstituicaoEnsino = InstituicaoEnsinoRepo.save(p);
		return createdInstituicaoEnsino;
	}

	@PutMapping("/api/instituicaoEnsino/{instituicaoEnsinoId}")
	Optional<InstituicaoEnsino> updateInstituicaoEnsino(@RequestBody InstituicaoEnsino instituicaoEnsinoRequest, @PathVariable long instituicaoEnsinoId) {
		Optional<InstituicaoEnsino> opt = InstituicaoEnsinoRepo.findById(instituicaoEnsinoId);
		if (opt.isPresent()) {
			if (instituicaoEnsinoRequest.getId() == instituicaoEnsinoId) {
				InstituicaoEnsinoRepo.save(instituicaoEnsinoRequest);
				return opt;
			}
		}
		throw new ResponseStatusException(HttpStatus.NOT_FOUND,
				"Erro ao alterar dados do professor com id " + instituicaoEnsinoId);
	}

	@DeleteMapping(value = "/api/instituicaoEnsino/{id}")
	void deleteInstituicaoEnsino(@PathVariable long id) {
		InstituicaoEnsinoRepo.deleteById(id);
	}
}
