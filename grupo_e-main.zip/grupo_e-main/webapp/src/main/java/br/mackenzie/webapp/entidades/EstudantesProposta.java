package br.mackenzie.webapp.entidades;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="estudantes_proposta")
public class EstudantesProposta {
    
    @Id @GeneratedValue
    Long id;
    
    private Long estudanteId;
    private Long propostaId;

    @ManyToOne
    @JoinColumn(name = "propostaId", insertable = false, updatable = false)
    private Proposta proposta;

    @ManyToOne
    @JoinColumn(name = "estudanteId", insertable = false, updatable = false)
    private Estudante estudante;

    public Long getPropostaId() {
        return propostaId;
    }
    public void setPropostaId(Long propostaId) {
        this.propostaId = propostaId;
    }

    public long getEstudanteId() {
        return estudanteId;
    }
    public void setEstudanteId(long estudanteId) {
        this.estudanteId = estudanteId;
    }
    
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    
    public Proposta getProposta() {
        return proposta;
    }
    
    public void setProposta(Proposta proposta) {
        this.proposta = proposta;
    }
    
    public Estudante getEstudante() {
        return estudante;
    }

    public void setEstudante(Estudante estudante) {
        this.estudante = estudante;
    }

}
